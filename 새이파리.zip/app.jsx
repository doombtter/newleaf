// Main app shell
const NAV = [
  { id:'home', label:'홈', icon: Icons.Home },
  { id:'entry', label:'거래 입력', icon: Icons.Plus },
  { id:'customers', label:'거래처', icon: Icons.Users },
  { id:'inventory', label:'재고/품목', icon: Icons.Box },
  { id:'schedule', label:'파종/출하', icon: Icons.Sprout },
  { id:'stats', label:'매출 통계', icon: Icons.Chart },
];

const TITLES = {
  home: '홈',
  entry: '거래 입력',
  customers: '거래처 관리',
  inventory: '재고 / 품목 관리',
  schedule: '파종 / 출하 일정',
  stats: '매출 통계',
};

const App = () => {
  const [page, setPage] = React.useState('home');
  const [invoice, setInvoice] = React.useState(null);

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">새</div>
          <div className="brand-text">
            <b>새이파리</b>
            <span>육묘장 관리</span>
          </div>
        </div>
        {NAV.map(n => {
          const Ic = n.icon;
          return (
            <div key={n.id} className={'nav-item' + (page===n.id?' active':'')} onClick={()=>setPage(n.id)}>
              <span className="ic"><Ic size={18}/></span>
              <span>{n.label}</span>
            </div>
          );
        })}
        <div className="nav-item">
          <span className="ic"><Icons.Settings size={18}/></span>
          <span>설정 / 백업</span>
        </div>
        <div className="footer">
          v1.0 · 단일 PC 오프라인 모드<br/>
          마지막 자동 백업 2026.05.07 06:00
        </div>
      </aside>

      <main className="main">
        <div className="topbar">
          <div className="row" style={{gap:14}}>
            <h1>{TITLES[page]}</h1>
            {page === 'home' && <span className="pill">단일 PC · 오프라인</span>}
          </div>
          <div className="meta">
            <div className="row" style={{gap:6}}><Icons.Calendar size={16}/> {window.TODAY.label}</div>
            <div className="row" style={{gap:6}}>
              <span style={{position:'relative'}}>
                <Icons.Bell size={18}/>
                <span style={{position:'absolute', top:-2, right:-2, width:8, height:8, borderRadius:'50%', background:'var(--warn)'}}/>
              </span>
              <span style={{fontWeight:600}}>{window.BIZ.owner} 사장님</span>
            </div>
          </div>
        </div>
        <div className="content">
          {page === 'home' && <HomeScreen onNav={setPage}/>}
          {page === 'entry' && <EntryScreen onPrint={(d) => setInvoice(d)}/>}
          {page === 'customers' && <CustomersScreen/>}
          {page === 'inventory' && <InventoryScreen/>}
          {page === 'schedule' && <ScheduleScreen/>}
          {page === 'stats' && <StatsScreen/>}
        </div>
      </main>

      <InvoiceModal data={invoice} onClose={()=>setInvoice(null)}/>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('app')).render(<App/>);
