// Transaction entry screen with autocomplete
const { useState, useMemo, useRef, useEffect } = React;

// Korean initial extraction
const HANGUL_INITIALS = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
const getInitials = (str) => {
  let out = '';
  for (const ch of str) {
    const code = ch.charCodeAt(0);
    if (code >= 0xAC00 && code <= 0xD7A3) {
      out += HANGUL_INITIALS[Math.floor((code - 0xAC00) / 588)];
    } else if (HANGUL_INITIALS.includes(ch)) {
      out += ch;
    } else {
      out += ch;
    }
  }
  return out;
};

const ItemAutocomplete = ({ value, onSelect, onChange, autoFocus }) => {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const ref = useRef(null);

  const candidates = useMemo(() => {
    const q = value.trim();
    if (!q) {
      // recent items
      return window.RECENT_ITEMS.map(id => window.findItem(id)).filter(Boolean);
    }
    const qInit = getInitials(q);
    const isInitOnly = /^[ㄱ-ㅎ]+$/.test(q);
    const scored = window.ITEMS.map(it => {
      const fullInit = it.initials || getInitials(it.name);
      let score = 0;
      if (isInitOnly) {
        if (fullInit.startsWith(qInit)) score = 100;
        else if (fullInit.includes(qInit)) score = 50;
      } else {
        if (it.name.startsWith(q)) score = 100;
        else if (it.name.includes(q)) score = 70;
        else if ((it.variety||'').includes(q)) score = 50;
        else if (fullInit.includes(qInit)) score = 30;
      }
      return { it, score };
    }).filter(x => x.score > 0)
      .sort((a,b) => b.score - a.score || b.it.useCount - a.it.useCount)
      .slice(0,8);
    return scored.map(x => x.it);
  }, [value]);

  useEffect(() => {
    const onClick = (e) => { if (!ref.current?.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const handleKey = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(a => Math.min(candidates.length-1, a+1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(a => Math.max(0, a-1)); }
    else if (e.key === 'Enter' && open && candidates[active]) {
      e.preventDefault();
      onSelect(candidates[active]);
      setOpen(false);
    } else if (e.key === 'Escape') {
      setOpen(false);
    }
  };

  return (
    <div className="ac-wrap" ref={ref}>
      <input
        className="row-input"
        style={{width:'100%'}}
        value={value}
        autoFocus={autoFocus}
        placeholder="품목 입력 (초성 ㅊㅇㄱㅊ / 부분 '복합')"
        onChange={(e) => { onChange(e.target.value); setOpen(true); setActive(0); }}
        onFocus={() => setOpen(true)}
        onKeyDown={handleKey}
      />
      {open && candidates.length > 0 && (
        <div className="ac-list">
          {!value.trim() && <div className="ac-section">최근 사용한 품목</div>}
          {candidates.map((it, i) => (
            <div key={it.id}
              className={'ac-item' + (i === active ? ' active' : '')}
              onMouseDown={(e) => { e.preventDefault(); onSelect(it); setOpen(false); }}
              onMouseEnter={() => setActive(i)}>
              <div>
                <b>{it.name}</b>
                {it.variety && <span className="muted" style={{marginLeft:6, fontSize:12}}>· {it.variety}</span>}
                <span className="muted" style={{marginLeft:8, fontSize:12}}>{it.spec}</span>
              </div>
              <div className="meta mono">{window.fmt(it.price)}원</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const blankRow = () => ({ key: Math.random().toString(36).slice(2), itemId: null, itemName: '', spec: '', qty: '', price: 0 });

const EntryScreen = ({ onPrint }) => {
  const [customerId, setCustomerId] = useState(1);
  const [date] = useState('2026.05.07');
  const [rows, setRows] = useState([
    { key: 'r1', itemId: 3, itemName: '순한조생복합', spec: '50구', qty: 30, price: 15000 },
    { key: 'r2', itemId: 1, itemName: '청양고추', spec: '50구', qty: 12, price: 15000 },
    blankRow(),
  ]);
  const [payment, setPayment] = useState('cash');
  const [memo, setMemo] = useState('');
  const [vatIncluded, setVatIncluded] = useState(false);

  const updateRow = (key, patch) => {
    setRows(rs => {
      const next = rs.map(r => r.key === key ? {...r, ...patch} : r);
      // ensure trailing blank
      if (next[next.length-1].itemId) next.push(blankRow());
      return next;
    });
  };

  const removeRow = (key) => setRows(rs => rs.filter(r => r.key !== key).concat(rs.length === 1 ? [blankRow()] : []));

  const subtotal = rows.reduce((a,r) => a + (r.qty || 0) * (r.price || 0), 0);
  const vat = vatIncluded ? Math.round(subtotal / 11) : Math.round(subtotal * 0.1);
  const total = vatIncluded ? subtotal : subtotal + vat;

  const customer = window.findCustomer(customerId);

  return (
    <div data-screen-label="02 거래입력" className="entry-grid">
      <div className="card">
        <div className="card-head">
          <h2>새 거래명세서</h2>
          <div className="row" style={{gap:8}}>
            <span className="muted" style={{fontSize:13}}>저장 단축키</span>
            <span className="keyhint">Ctrl+S</span>
            <span className="keyhint">Ctrl+P</span>
          </div>
        </div>

        <div className="card-body" style={{display:'flex', flexDirection:'column', gap:18}}>
          {/* Header fields */}
          <div style={{display:'grid', gridTemplateColumns:'180px 1fr 220px', gap:14}}>
            <div className="field">
              <label>거래일자</label>
              <input className="input mono" value={date} readOnly/>
            </div>
            <div className="field">
              <label>거래처</label>
              <select className="select" value={customerId} onChange={e=>setCustomerId(Number(e.target.value))}>
                {window.CUSTOMERS.map(c => (
                  <option key={c.id} value={c.id}>{c.name} ({c.tier === 'wholesale' ? '도매가' : c.tier === 'regular' ? '단골가' : '일반가'})</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>이전 미수금</label>
              <div className="input mono" style={{display:'flex', alignItems:'center', justifyContent:'flex-end',
                color: customer.due > 0 ? 'var(--warn)' : 'var(--ink-muted)', fontWeight: 700, background:'#FBF7EE'}}>
                {window.fmt(customer.due)}원
              </div>
            </div>
          </div>

          {/* Items */}
          <div>
            <div className="row-grid head">
              <div>월/일</div><div>품목</div><div>규격</div><div className="right">수량</div><div className="right">단가</div><div className="right">공급가액</div><div></div>
            </div>
            <div className="col" style={{gap:6, paddingTop:8}}>
              {rows.map((r, idx) => (
                <div key={r.key} className="row-grid">
                  <input className="row-input mono" defaultValue="5/7" style={{textAlign:'center'}}/>
                  <ItemAutocomplete
                    value={r.itemName}
                    onChange={v => updateRow(r.key, { itemName: v })}
                    onSelect={(it) => updateRow(r.key, { itemId: it.id, itemName: it.name + (it.variety ? ` · ${it.variety}` : ''), spec: it.spec, price: it.price })}
                  />
                  <input className="row-input" value={r.spec} onChange={e=>updateRow(r.key,{spec:e.target.value})} placeholder="규격"/>
                  <input className="row-input row-num" value={r.qty} onChange={e=>updateRow(r.key,{qty: Number(e.target.value)||0})} placeholder="0"/>
                  <input className="row-input row-num" value={r.price} onChange={e=>updateRow(r.key,{price: Number(e.target.value)||0})} placeholder="0"/>
                  <div className="row-input row-num" style={{background:'#FBF7EE', display:'flex', alignItems:'center', justifyContent:'flex-end', fontWeight:600}}>
                    {window.fmt((r.qty||0)*(r.price||0))}
                  </div>
                  <button className="btn btn-sm btn-ghost" onClick={()=>removeRow(r.key)} title="행 삭제"><Icons.Trash size={16}/></button>
                </div>
              ))}
            </div>
          </div>

          {/* Memo / VAT */}
          <div style={{display:'grid', gridTemplateColumns:'1fr 280px', gap:14}}>
            <div className="field">
              <label>비고</label>
              <textarea className="textarea" rows={2} value={memo} onChange={e=>setMemo(e.target.value)} placeholder="거래 관련 메모 (선택)"/>
            </div>
            <div className="field">
              <label>결제 방식</label>
              <div className="seg" style={{width:'100%'}}>
                <button className={payment==='cash'?'on':''} style={{flex:1}} onClick={()=>setPayment('cash')}>현금</button>
                <button className={payment==='transfer'?'on':''} style={{flex:1}} onClick={()=>setPayment('transfer')}>이체</button>
                <button className={payment==='credit'?'on':''} style={{flex:1}} onClick={()=>setPayment('credit')}>외상</button>
              </div>
              <label style={{marginTop:6, display:'flex', alignItems:'center', gap:6, fontSize:13}}>
                <input type="checkbox" checked={vatIncluded} onChange={e=>setVatIncluded(e.target.checked)}/>
                부가세 포함 단가
              </label>
            </div>
          </div>
        </div>

        <div className="entry-footer">
          <div className="totals">
            <div><span className="lbl">공급가</span> <span className="val mono">{window.fmt(subtotal)}원</span></div>
            <div><span className="lbl">부가세</span> <span className="val mono">{window.fmt(vat)}원</span></div>
            <div><span className="lbl">합계</span> <span className="val grand mono">{window.fmt(total)}원</span></div>
          </div>
          <div className="row" style={{gap:10}}>
            <button className="btn btn-lg">취소</button>
            <button className="btn btn-lg"><Icons.Save size={18}/> 저장</button>
            <button className="btn btn-lg btn-primary" onClick={()=>onPrint({ customer, date, rows: rows.filter(r=>r.itemId), subtotal, vat, total, payment, memo })}>
              <Icons.Print size={18}/> 저장 후 인쇄
            </button>
          </div>
        </div>
      </div>

      {/* Right: favorites */}
      <div className="col" style={{gap:14}}>
        <div className="card">
          <div className="card-head"><h2><Icons.Star size={16}/> 즐겨찾는 품목</h2></div>
          <div className="card-body" style={{padding:14}}>
            <div className="fav-list">
              {window.FAVORITE_ITEMS.slice(0,10).map((id, i) => {
                const it = window.findItem(id);
                if (!it) return null;
                return (
                  <button className="fav-item" key={id}
                    onClick={() => updateRow(rows.find(r=>!r.itemId)?.key, { itemId: it.id, itemName: it.name + (it.variety?` · ${it.variety}`:''), spec: it.spec, price: it.price, qty: 1 })}>
                    <div className="row" style={{gap:10}}>
                      <span className="fav-rank">{i+1}</span>
                      <div>
                        <div className="name">{it.name}{it.variety && <span className="muted" style={{fontWeight:400, marginLeft:4, fontSize:12}}>· {it.variety}</span>}</div>
                        <div className="spec">{it.spec} · {window.fmt(it.price)}원</div>
                      </div>
                    </div>
                    <Icons.Plus size={16}/>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-head"><h2>거래 템플릿</h2></div>
          <div className="card-body" style={{padding:14}}>
            <div className="fav-list">
              <div className="fav-item">
                <div>
                  <div className="name">한빛농협 정기납품</div>
                  <div className="spec">청양고추·토마토·오이 정기 5종</div>
                </div>
                <Icons.ArrowRight size={16}/>
              </div>
              <div className="fav-item">
                <div>
                  <div className="name">김농부 단골 묶음</div>
                  <div className="spec">고추 50구 + 상추 200구</div>
                </div>
                <Icons.ArrowRight size={16}/>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

window.EntryScreen = EntryScreen;
