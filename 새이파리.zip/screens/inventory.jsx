// Inventory screen
const InventoryScreen = () => {
  const [filter, setFilter] = React.useState('all');
  let items = window.ITEMS;
  if (filter === 'low') items = items.filter(i => i.stock < i.safety);
  if (filter === 'good') items = items.filter(i => i.stock >= i.safety);

  return (
    <div data-screen-label="04 재고" className="col" style={{gap:18}}>
      {/* Top stats */}
      <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14}}>
        <div className="stat">
          <div className="label">총 품목 수</div>
          <div className="value">{window.ITEMS.length}<span style={{fontSize:14, color:'var(--ink-muted)', marginLeft:6, fontFamily:'inherit'}}>종</span></div>
        </div>
        <div className="stat">
          <div className="label">재고 총량</div>
          <div className="value">{window.ITEMS.reduce((a,i)=>a+i.stock,0)}<span style={{fontSize:14, color:'var(--ink-muted)', marginLeft:6, fontFamily:'inherit'}}>트레이</span></div>
        </div>
        <div className="stat danger">
          <div className="label">안전재고 미달</div>
          <div className="value">{window.ITEMS.filter(i=>i.stock<i.safety).length}<span style={{fontSize:14, color:'var(--ink-muted)', marginLeft:6, fontFamily:'inherit'}}>종</span></div>
          <div className="delta" style={{color:'var(--danger)'}}>즉시 파종 검토</div>
        </div>
        <div className="stat">
          <div className="label">진행 중 파종 (출하 예정)</div>
          <div className="value">{window.SOWINGS.reduce((a,s)=>a+s.trays,0)}<span style={{fontSize:14, color:'var(--ink-muted)', marginLeft:6, fontFamily:'inherit'}}>트레이</span></div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <div className="row" style={{gap:14}}>
            <h2>품목 마스터 / 재고 현황</h2>
            <div className="seg">
              <button className={filter==='all'?'on':''} onClick={()=>setFilter('all')}>전체</button>
              <button className={filter==='low'?'on':''} onClick={()=>setFilter('low')}>안전재고 미달</button>
              <button className={filter==='good'?'on':''} onClick={()=>setFilter('good')}>정상</button>
            </div>
          </div>
          <div className="row" style={{gap:8}}>
            <button className="btn btn-sm">파종 입고</button>
            <button className="btn btn-sm">조정</button>
            <button className="btn btn-sm btn-primary"><Icons.Plus size={14}/> 신규 품목</button>
          </div>
        </div>
        <div className="card-body tight">
          <table className="tx">
            <thead><tr>
              <th>품목</th>
              <th style={{width:80}}>품종</th>
              <th style={{width:70}}>규격</th>
              <th className="num" style={{width:100}}>기본단가</th>
              <th style={{width:200}}>현재 재고 / 안전재고</th>
              <th className="num" style={{width:80}}>육묘일</th>
              <th className="num" style={{width:80}}>판매빈도</th>
              <th style={{width:80}}>상태</th>
            </tr></thead>
            <tbody>
              {items.map(it => {
                const ratio = it.stock / Math.max(1, it.safety * 2);
                const cls = it.stock < it.safety ? 'danger' : it.stock < it.safety * 1.5 ? 'warn' : '';
                return (
                  <tr key={it.id}>
                    <td><b>{it.name}</b></td>
                    <td>{it.variety || '—'}</td>
                    <td>{it.spec}</td>
                    <td className="num">{window.fmt(it.price)}원</td>
                    <td>
                      <div className="row" style={{justifyContent:'space-between', marginBottom:4, fontSize:12}}>
                        <b className="mono">{it.stock} 트레이</b>
                        <span className="muted mono">안전 {it.safety}</span>
                      </div>
                      <div className="stock-bar">
                        <div className={'fill ' + cls} style={{width: Math.min(100, ratio*100)+'%'}}/>
                      </div>
                    </td>
                    <td className="num">{it.growing}일</td>
                    <td className="num">{it.useCount}회</td>
                    <td>
                      {it.stock < it.safety
                        ? <span className="tag tag-danger">미달</span>
                        : it.stock < it.safety * 1.5
                          ? <span className="tag tag-warn">부족</span>
                          : <span className="tag tag-green">정상</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

window.InventoryScreen = InventoryScreen;
