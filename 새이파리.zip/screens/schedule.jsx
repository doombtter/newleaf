// Sowing / shipping schedule
const ScheduleScreen = () => {
  const [view, setView] = React.useState('cal');
  // 2026 May, May 1 = Friday
  const monthStart = 5; // Friday => col index 5 (Sun=0)
  const daysInMonth = 31;
  const cells = [];
  for (let i = 0; i < monthStart; i++) cells.push({ dim:true, d: 30 - monthStart + i + 1 });
  for (let d = 1; d <= daysInMonth; d++) cells.push({ d });
  while (cells.length % 7 !== 0) cells.push({ dim:true, d: cells.length - daysInMonth - monthStart + 1 });

  const shipMap = {};
  const sowMap = {};
  window.SOWINGS.forEach(s => {
    const [y,m,d] = s.shipDate.split('.').map(Number);
    if (m === 5) (shipMap[d] = shipMap[d] || []).push(s);
    const [sy,sm,sd] = s.sowDate.split('.').map(Number);
    if (sm === 5) (sowMap[sd] = sowMap[sd] || []).push(s);
  });

  return (
    <div data-screen-label="05 일정" className="col" style={{gap:18}}>
      <div className="card">
        <div className="card-head">
          <div className="row" style={{gap:14}}>
            <button className="btn btn-sm"><Icons.ChevronLeft size={14}/></button>
            <h2 style={{minWidth:120}}>2026년 5월</h2>
            <button className="btn btn-sm"><Icons.ChevronRight size={14}/></button>
            <button className="btn btn-sm">오늘</button>
          </div>
          <div className="row" style={{gap:10}}>
            <div className="seg">
              <button className={view==='cal'?'on':''} onClick={()=>setView('cal')}>캘린더</button>
              <button className={view==='list'?'on':''} onClick={()=>setView('list')}>리스트</button>
            </div>
            <button className="btn btn-sm btn-primary"><Icons.Plus size={14}/> 파종 등록</button>
          </div>
        </div>

        {view === 'cal' && (
          <div className="card-body tight">
            <div className="cal-grid">
              {['일','월','화','수','목','금','토'].map(d => <div key={d} className="cal-head">{d}</div>)}
              {cells.map((c, i) => {
                const isToday = !c.dim && c.d === 7;
                const ships = !c.dim ? (shipMap[c.d] || []) : [];
                const sows = !c.dim ? (sowMap[c.d] || []) : [];
                const isSun = i % 7 === 0;
                return (
                  <div key={i} className={'cal-cell' + (c.dim?' dim':'') + (isToday?' today':'')}>
                    <div className={'d' + (isSun?' sun':'')}>{c.d}{isToday && <span style={{marginLeft:6, fontSize:11, color:'var(--green-800)', fontWeight:700}}>오늘</span>}</div>
                    {ships.map(s => {
                      const it = window.findItem(s.itemId);
                      const days = (Number(s.shipDate.split('.')[2]) - 7);
                      const cls = days <= 1 ? 'danger' : days <= 3 ? 'warn' : '';
                      return <div key={'sh'+s.id} className={'cal-pill ' + cls}>🚚 {it.name} {s.trays}T</div>;
                    })}
                    {sows.map(s => {
                      const it = window.findItem(s.itemId);
                      return <div key={'so'+s.id} className="cal-pill" style={{background:'#E8F0FA', color:'#1D4F8A'}}>🌱 {it.name} 파종</div>;
                    })}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {view === 'list' && (
          <div className="card-body tight">
            <table className="tx">
              <thead><tr>
                <th style={{width:90}}>출하 예정일</th>
                <th style={{width:60}}>D-day</th>
                <th>품목</th>
                <th style={{width:80}}>규격</th>
                <th className="num" style={{width:80}}>트레이</th>
                <th style={{width:90}}>파종일</th>
                <th style={{width:90}}>경과</th>
                <th style={{width:100}}>상태</th>
              </tr></thead>
              <tbody>
                {[...window.SOWINGS].sort((a,b)=>a.shipDate.localeCompare(b.shipDate)).map(s => {
                  const it = window.findItem(s.itemId);
                  const dday = Number(s.shipDate.split('.')[2]) + (Number(s.shipDate.split('.')[1])-5)*30 - 7;
                  const elapsed = (Number(s.shipDate.split('.')[2]) - Number(s.sowDate.split('.')[2])) + (Number(s.shipDate.split('.')[1]) - Number(s.sowDate.split('.')[1]))*30 - dday;
                  return (
                    <tr key={s.id}>
                      <td className="mono"><b>{s.shipDate}</b></td>
                      <td><span className={'tag ' + (dday<=1?'tag-danger':dday<=3?'tag-warn':'tag-neutral')}>{dday<=0?'D-day':`D-${dday}`}</span></td>
                      <td><b>{it.name}</b> {it.variety && <span className="muted">· {it.variety}</span>}</td>
                      <td>{s.traySize}구</td>
                      <td className="num"><b>{s.trays}</b></td>
                      <td className="mono">{s.sowDate}</td>
                      <td>{elapsed}일째</td>
                      <td>
                        {s.status==='germinating' && <span className="tag tag-neutral">발아중</span>}
                        {s.status==='growing' && <span className="tag tag-green">육묘중</span>}
                        {s.status==='shipped' && <span className="tag tag-neutral">출하완료</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

window.ScheduleScreen = ScheduleScreen;
