// Stats screen
const Sparkline = ({ data, w=720, h=200 }) => {
  const max = Math.max(...data.map(d=>d[1]), 1);
  const stepX = w / (data.length - 1);
  const pts = data.map((d,i) => [i*stepX, h - (d[1]/max) * (h-30) - 6]);
  const path = pts.map((p,i) => (i===0?'M':'L') + p[0].toFixed(1)+','+p[1].toFixed(1)).join(' ');
  const area = path + ` L${w},${h} L0,${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{width:'100%', height:240}}>
      <defs>
        <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3A7A52" stopOpacity="0.3"/>
          <stop offset="100%" stopColor="#3A7A52" stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={area} fill="url(#g)"/>
      <path d={path} fill="none" stroke="#2D5F3F" strokeWidth="2.5" strokeLinejoin="round"/>
      {pts.map((p,i) => (
        <g key={i}>
          <circle cx={p[0]} cy={p[1]} r="3" fill="#fff" stroke="#2D5F3F" strokeWidth="2"/>
          <text x={p[0]} y={h-2} fontSize="10" fill="#8A8579" textAnchor="middle">{data[i][0]}</text>
        </g>
      ))}
    </svg>
  );
};

const StatsScreen = () => {
  const [period, setPeriod] = React.useState('month');

  const itemSales = [
    { name: '청양고추 50구', amt: 3240000 },
    { name: '순한조생복합 50구', amt: 2880000 },
    { name: '토마토 50구', amt: 1840000 },
    { name: '오이 50구', amt: 1340000 },
    { name: '상추 200구', amt: 980000 },
    { name: '수박 50구', amt: 820000 },
    { name: '양배추 128구', amt: 690000 },
    { name: '가지 72구', amt: 510000 },
  ];
  const maxItem = Math.max(...itemSales.map(i=>i.amt));

  const customerSales = [
    { name: '한빛농협 자재센터', amt: 4120000 },
    { name: '새벽농산', amt: 2680000 },
    { name: '유나물상회', amt: 1840000 },
    { name: '김농부 (덕진농원)', amt: 1320000 },
    { name: '박재성', amt: 880000 },
    { name: '정원예 (광활농장)', amt: 760000 },
    { name: '조한석', amt: 520000 },
    { name: '이순례', amt: 360000 },
  ];
  const maxCust = Math.max(...customerSales.map(i=>i.amt));

  return (
    <div data-screen-label="06 통계" className="col" style={{gap:18}}>
      <div className="card">
        <div className="card-head">
          <h2>매출 통계</h2>
          <div className="row" style={{gap:10}}>
            <div className="seg">
              <button className={period==='week'?'on':''} onClick={()=>setPeriod('week')}>이번 주</button>
              <button className={period==='month'?'on':''} onClick={()=>setPeriod('month')}>이번 달</button>
              <button className={period==='quarter'?'on':''} onClick={()=>setPeriod('quarter')}>이번 분기</button>
              <button className={period==='year'?'on':''} onClick={()=>setPeriod('year')}>올해</button>
            </div>
            <button className="btn btn-sm"><Icons.Calendar size={14}/> 사용자 지정</button>
          </div>
        </div>
        <div className="card-body">
          <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14, marginBottom:18}}>
            <div className="stat">
              <div className="label">총 매출</div>
              <div className="value">{window.fmt(window.MONTHLY_TOTAL)}원</div>
              <div className="delta">전년 동월 대비 +12.4%</div>
            </div>
            <div className="stat">
              <div className="label">총 수금</div>
              <div className="value" style={{color:'var(--green-800)'}}>{window.fmt(window.MONTHLY_PAID)}원</div>
              <div className="delta">수금률 77.1%</div>
            </div>
            <div className="stat warn">
              <div className="label">미수금 잔액</div>
              <div className="value">{window.fmt(window.MONTHLY_DUE)}원</div>
            </div>
            <div className="stat">
              <div className="label">거래 건수</div>
              <div className="value">12<span style={{fontSize:14, color:'var(--ink-muted)', marginLeft:6, fontFamily:'inherit'}}>건</span></div>
              <div className="delta">평균 1,040,000원/건</div>
            </div>
          </div>

          <div className="section-title"><h2>일별 매출 추이 (최근 14일)</h2></div>
          <Sparkline data={window.DAILY_REVENUE}/>
        </div>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:18}}>
        <div className="card">
          <div className="card-head"><h2>품목별 매출 순위</h2></div>
          <div className="card-body">
            {itemSales.map((it,i) => (
              <div key={i} className="bar-row">
                <div className="name"><span className="muted mono" style={{marginRight:8}}>{i+1}</span>{it.name}</div>
                <div className="bar-track"><div className="bar-fill" style={{width: (it.amt/maxItem*100)+'%'}}/></div>
                <div className="num">{window.fmt(it.amt)}원</div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-head"><h2>거래처별 매출 순위</h2></div>
          <div className="card-body">
            {customerSales.map((c,i) => (
              <div key={i} className="bar-row">
                <div className="name"><span className="muted mono" style={{marginRight:8}}>{i+1}</span>{c.name}</div>
                <div className="bar-track"><div className="bar-fill" style={{width: (c.amt/maxCust*100)+'%', background:'#3A7A52'}}/></div>
                <div className="num">{window.fmt(c.amt)}원</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h2>엑셀 내보내기</h2>
          <span className="muted" style={{fontSize:13}}>오프라인 SheetJS · 인터넷 불필요</span>
        </div>
        <div className="card-body" style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12}}>
          {[
            ['거래 내역', '기간 내 모든 거래', 'transactions_2026-05.xlsx'],
            ['거래처별 집계', '매출/미수금', 'customers_2026-05.xlsx'],
            ['품목별 판매', '품목·규격·수량', 'items_2026-05.xlsx'],
            ['재고 현황', '안전재고 포함', 'stock_2026-05-07.xlsx'],
            ['파종/출하 일정', '진행중 + 완료', 'sowings_2026-05.xlsx'],
            ['전체 백업 (DB)', 'SQLite + xlsx 묶음', 'backup_2026-05-07.zip'],
          ].map(([t,d,f],i) => (
            <button key={i} className="alert-card" style={{textAlign:'left', cursor:'pointer'}}>
              <div className="badge"><Icons.Download size={18}/></div>
              <div className="body">
                <h4>{t}</h4>
                <p>{d} · <span className="mono" style={{fontSize:12}}>{f}</span></p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

window.StatsScreen = StatsScreen;
