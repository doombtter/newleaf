// Customer manager
const CustomersScreen = () => {
  const [selectedId, setSelectedId] = React.useState(2);
  const [tab, setTab] = React.useState('history');
  const [search, setSearch] = React.useState('');
  const sorted = [...window.CUSTOMERS].sort((a,b) => b.due - a.due);
  const filtered = sorted.filter(c => !search || c.name.includes(search) || (c.phone||'').includes(search));
  const c = window.findCustomer(selectedId);
  const txs = window.TRANSACTIONS.filter(t => t.customerId === selectedId);

  return (
    <div data-screen-label="03 거래처" className="split-grid">
      <div className="list-card" style={{height: 'calc(100vh - 160px)', overflow:'hidden', display:'flex', flexDirection:'column'}}>
        <div className="list-search">
          <div style={{position:'relative'}}>
            <input placeholder="거래처명 / 전화번호 검색" value={search} onChange={e=>setSearch(e.target.value)} style={{paddingLeft:34}}/>
            <span style={{position:'absolute', left:12, top:12, color:'var(--ink-muted)'}}><Icons.Search size={16}/></span>
          </div>
          <div className="row" style={{justifyContent:'space-between', marginTop:10, fontSize:12, color:'var(--ink-muted)'}}>
            <span>총 {filtered.length}곳 · 미수금 잔액 순</span>
            <button className="btn btn-sm" style={{height:30}}><Icons.Plus size={14}/> 신규</button>
          </div>
        </div>
        <div style={{overflow:'auto', flex:1}}>
          {filtered.map(c => (
            <div key={c.id} className={'list-row' + (c.id===selectedId?' selected':'')} onClick={()=>setSelectedId(c.id)}>
              <div>
                <div className="nm">{c.name}</div>
                <div className="sub">{c.tier === 'wholesale' ? '도매가' : c.tier === 'regular' ? '단골가' : '일반가'} · {c.phone}</div>
              </div>
              <div className={'due ' + (c.due === 0 ? 'zero':'')}>{c.due === 0 ? '—' : window.fmt(c.due)+'원'}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="col" style={{gap: 18}}>
        <div className="card">
          <div className="card-head">
            <div>
              <h2 style={{marginBottom:4}}>{c.name}</h2>
              <div className="muted" style={{fontSize:13}}>{c.type === 'wholesale' ? '도매 거래처' : '개인 농가'} · 마지막 거래 {c.last}</div>
            </div>
            <div className="row" style={{gap:8}}>
              <button className="btn btn-sm">정보 수정</button>
              <button className="btn btn-sm btn-primary"><Icons.Wallet size={16}/> 수금 입력</button>
            </div>
          </div>
          <div className="card-body">
            <div className="detail-grid">
              <div className="kv"><span className="k">대표자</span><span className="v">{c.owner}</span></div>
              <div className="kv"><span className="k">연락처</span><span className="v mono">{c.phone}</span></div>
              <div className="kv" style={{gridColumn:'span 2'}}><span className="k">주소</span><span className="v" style={{fontSize:14}}>{c.address}</span></div>
              <div className="kv"><span className="k">단가 등급</span><span className="v">{c.tier === 'wholesale' ? '도매가' : c.tier === 'regular' ? '단골가' : '일반가'}</span></div>
              <div className="kv"><span className="k">올해 누적 매출</span><span className="v mono">3,820,000원</span></div>
              <div className="kv"><span className="k">올해 거래 건수</span><span className="v">14건</span></div>
              <div className="kv" style={{background: c.due > 0 ? 'var(--warn-soft)':'var(--green-50)'}}>
                <span className="k">미수금 잔액</span>
                <span className="v mono" style={{color: c.due > 0 ? 'var(--warn)':'var(--green-800)'}}>{window.fmt(c.due)}원</span>
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-body" style={{paddingBottom:0}}>
            <div className="tabs">
              <div className={'tab' + (tab==='history'?' on':'')} onClick={()=>setTab('history')}>거래 이력</div>
              <div className={'tab' + (tab==='due'?' on':'')} onClick={()=>setTab('due')}>미수금 명세</div>
              <div className={'tab' + (tab==='prices'?' on':'')} onClick={()=>setTab('prices')}>전용 단가표</div>
              <div className={'tab' + (tab==='memo'?' on':'')} onClick={()=>setTab('memo')}>메모</div>
            </div>
          </div>
          <div className="card-body tight">
            {tab === 'history' && (
              <table className="tx">
                <thead><tr>
                  <th style={{width:90}}>거래일</th><th>품목 요약</th>
                  <th className="num" style={{width:140}}>합계</th>
                  <th style={{width:100}}>결제</th>
                  <th style={{width:80}}></th>
                </tr></thead>
                <tbody>
                  {txs.length === 0 && <tr><td colSpan="5" style={{textAlign:'center', padding:40, color:'var(--ink-muted)'}}>거래 이력 없음</td></tr>}
                  {txs.map(t => (
                    <tr key={t.id}>
                      <td className="mono">{t.date}</td>
                      <td>품목 {t.items}건 <span className="muted" style={{fontSize:12, marginLeft:6}}>#{t.id}</span></td>
                      <td className="num"><b>{window.fmt(t.total)}원</b></td>
                      <td>
                        {t.method === 'cash' && <span className="tag tag-green">현금</span>}
                        {t.method === 'transfer' && <span className="tag tag-green">이체</span>}
                        {t.method === 'credit' && <span className="tag tag-warn">외상</span>}
                      </td>
                      <td><button className="btn btn-sm btn-ghost"><Icons.Print size={14}/></button></td>
                    </tr>
                  ))}
                  <tr style={{background:'#FBF7EE'}}>
                    <td colSpan="2"><b>14건 합계 (올해)</b></td>
                    <td className="num"><b>3,820,000원</b></td>
                    <td colSpan="2"></td>
                  </tr>
                </tbody>
              </table>
            )}
            {tab === 'due' && c.due > 0 && (
              <div style={{padding:22}}>
                <div className="alert-card warn">
                  <div className="badge"><Icons.Wallet size={20}/></div>
                  <div className="body">
                    <h4>미수금 합계 {window.fmt(c.due)}원</h4>
                    <p>외상 거래 {txs.filter(t=>t.method==='credit').length}건이 누적되어 있습니다.</p>
                  </div>
                </div>
                <table className="tx" style={{marginTop:14}}>
                  <thead><tr><th>거래일</th><th>거래번호</th><th className="num">금액</th><th className="num">미수</th><th></th></tr></thead>
                  <tbody>
                    {txs.filter(t=>t.method==='credit').map(t => (
                      <tr key={t.id}>
                        <td className="mono">{t.date}</td>
                        <td className="mono">#{t.id}</td>
                        <td className="num">{window.fmt(t.total)}원</td>
                        <td className="num" style={{color:'var(--warn)'}}><b>{window.fmt(t.total)}원</b></td>
                        <td><button className="btn btn-sm btn-primary">수금 입력</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {tab === 'due' && c.due === 0 && <div style={{padding:60, textAlign:'center', color:'var(--ink-muted)'}}>미수금 없음 ✓</div>}
            {tab === 'prices' && (
              <table className="tx">
                <thead><tr><th>품목</th><th>규격</th><th className="num">기본가</th><th className="num">{c.name} 적용가</th><th></th></tr></thead>
                <tbody>
                  {window.ITEMS.slice(0,5).map(it => (
                    <tr key={it.id}>
                      <td>{it.name} {it.variety && <span className="muted">· {it.variety}</span>}</td>
                      <td>{it.spec}</td>
                      <td className="num">{window.fmt(it.price)}원</td>
                      <td className="num"><b>{window.fmt(Math.round(it.price * (c.tier==='wholesale'?0.85:c.tier==='regular'?0.93:1)))}원</b></td>
                      <td><button className="btn btn-sm btn-ghost">수정</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            {tab === 'memo' && (
              <div style={{padding:22}}>
                <textarea className="textarea" rows={6} defaultValue={c.memo} style={{width:'100%'}}/>
                <button className="btn btn-sm btn-primary" style={{marginTop:10}}>메모 저장</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

window.CustomersScreen = CustomersScreen;
