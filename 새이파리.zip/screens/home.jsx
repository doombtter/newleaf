// Home dashboard
const HomeScreen = ({ onNav }) => {
  const todayShipments = window.SOWINGS.filter(s => s.shipDate === '2026.05.08' || s.shipDate === '2026.05.07');
  const lowStock = window.ITEMS.filter(i => i.stock < i.safety);
  const dueCustomers = window.CUSTOMERS.filter(c => c.due > 0);
  const totalDue = dueCustomers.reduce((a,c)=>a+c.due,0);

  return (
    <div className="col" style={{gap:24}} data-screen-label="01 홈">
      {/* Top stats */}
      <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14}}>
        <div className="stat">
          <div className="label">이번 달 매출</div>
          <div className="value">{window.fmt(window.MONTHLY_TOTAL)}원</div>
          <div className="delta">전년 동월 대비 +12.4%</div>
        </div>
        <div className="stat">
          <div className="label">이번 달 수금</div>
          <div className="value" style={{color:'var(--green-800)'}}>{window.fmt(window.MONTHLY_PAID)}원</div>
          <div className="delta muted">9건 / 12건 결제완료</div>
        </div>
        <div className="stat warn">
          <div className="label">미수금 잔액</div>
          <div className="value">{window.fmt(totalDue)}원</div>
          <div className="delta" style={{color:'var(--warn)'}}>{dueCustomers.length}개 거래처</div>
        </div>
        <div className="stat">
          <div className="label">진행 중 파종</div>
          <div className="value">{window.SOWINGS.length}건</div>
          <div className="delta">이번 주 출하 {todayShipments.length}건</div>
        </div>
      </div>

      <div className="home-grid">
        {/* Alerts */}
        <div className="card">
          <div className="card-head">
            <h2>오늘의 알림</h2>
            <span className="muted" style={{fontSize:13}}>{window.TODAY.label}</span>
          </div>
          <div className="card-body" style={{display:'flex', flexDirection:'column', gap:12}}>
            <div className="alert-card warn">
              <div className="badge"><Icons.Sprout size={20}/></div>
              <div className="body">
                <h4>내일 출하 예정 — 청양고추 50구 12트레이</h4>
                <p>김농부(덕진농원) 픽업 / 파종 D+55 · 오늘 안에 픽업 알림 권장</p>
              </div>
              <button className="btn btn-sm" onClick={()=>onNav('schedule')}>일정 보기</button>
            </div>
            <div className="alert-card warn">
              <div className="badge"><Icons.Sprout size={20}/></div>
              <div className="body">
                <h4>오늘 출하 예정 — 수박 50구 10트레이</h4>
                <p>새벽농산 / 파종 D+31 · 접목묘 작황 양호</p>
              </div>
              <button className="btn btn-sm" onClick={()=>onNav('schedule')}>일정 보기</button>
            </div>
            <div className="alert-card danger">
              <div className="badge"><Icons.Box size={20}/></div>
              <div className="body">
                <h4>안전재고 미달 — 토마토 (찰찰이, 50구)</h4>
                <p>현재 3트레이 / 안전재고 20트레이 · 즉시 파종 검토 필요</p>
              </div>
              <button className="btn btn-sm" onClick={()=>onNav('inventory')}>재고 보기</button>
            </div>
            <div className="alert-card">
              <div className="badge"><Icons.Wallet size={20}/></div>
              <div className="body">
                <h4>미수금 누적 4개 거래처 · 합계 {window.fmt(totalDue)}원</h4>
                <p>한빛농협 자재센터 1,840,000원 · 김농부 320,000원 · 박재성 180,000원 · 외 2건</p>
              </div>
              <button className="btn btn-sm" onClick={()=>onNav('customers')}>수금 처리</button>
            </div>
          </div>
        </div>

        {/* Quick tiles */}
        <div className="col" style={{gap:14}}>
          <div className="section-title"><h2>빠른 작업</h2></div>
          <div className="tile-grid" style={{gridTemplateColumns:'1fr 1fr'}}>
            <button className="tile primary" onClick={()=>onNav('entry')}>
              <div className="ic"><Icons.Plus size={24}/></div>
              <div>
                <h3>거래 입력</h3>
                <p>새 거래명세서 작성 · Ctrl+N</p>
              </div>
            </button>
            <button className="tile" onClick={()=>onNav('customers')}>
              <div className="ic"><Icons.Users size={24}/></div>
              <div>
                <h3>거래처 관리</h3>
                <p>외상·미수금 현황</p>
              </div>
            </button>
            <button className="tile" onClick={()=>onNav('inventory')}>
              <div className="ic"><Icons.Box size={24}/></div>
              <div>
                <h3>재고 / 품목</h3>
                <p>입출고 이력</p>
              </div>
            </button>
            <button className="tile" onClick={()=>onNav('schedule')}>
              <div className="ic"><Icons.Sprout size={24}/></div>
              <div>
                <h3>파종 / 출하</h3>
                <p>일정 캘린더</p>
              </div>
            </button>
            <button className="tile" onClick={()=>onNav('stats')}>
              <div className="ic"><Icons.Chart size={24}/></div>
              <div>
                <h3>매출 통계</h3>
                <p>엑셀 내보내기</p>
              </div>
            </button>
            <button className="tile">
              <div className="ic"><Icons.Settings size={24}/></div>
              <div>
                <h3>설정 / 백업</h3>
                <p>USB 데이터 백업</p>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Recent transactions */}
      <div className="card">
        <div className="card-head">
          <h2>최근 거래 내역</h2>
          <button className="btn btn-sm" onClick={()=>onNav('stats')}>전체 보기</button>
        </div>
        <div className="card-body tight">
          <table className="tx">
            <thead><tr>
              <th style={{width:90}}>거래일</th>
              <th>거래처</th>
              <th style={{width:80}}>품목수</th>
              <th className="num" style={{width:140}}>합계</th>
              <th style={{width:100}}>결제</th>
              <th style={{width:60}}></th>
            </tr></thead>
            <tbody>
              {window.TRANSACTIONS.map(t => {
                const c = window.findCustomer(t.customerId);
                return (
                  <tr key={t.id}>
                    <td className="mono">{t.date}</td>
                    <td><b>{c.name}</b> <span className="muted" style={{fontSize:12, marginLeft:6}}>#{t.id}</span></td>
                    <td>{t.items}건</td>
                    <td className="num"><b>{window.fmt(t.total)}원</b></td>
                    <td>
                      {t.method === 'cash' && <span className="tag tag-green">현금</span>}
                      {t.method === 'transfer' && <span className="tag tag-green">이체</span>}
                      {t.method === 'credit' && <span className="tag tag-warn">외상</span>}
                    </td>
                    <td><button className="btn btn-sm btn-ghost"><Icons.Print size={16}/></button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

window.HomeScreen = HomeScreen;
